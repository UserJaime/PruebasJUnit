package org.example.Ejercicio12;

public class ComponenteA {

    public String operacionA() {
        // Lógica de la operación A
        return "Resultado de operación A";
    }
}
