package org.example.Ejercicio11;

public class PruebaServicioB implements PruebasComunes {

    @Override
    public boolean ejecucionBasica() {
        // Lógica específica de prueba para ServicioB
        // Simulamos que la ejecución es correcta
        return true;
    }

    // Otras pruebas específicas para ServicioB pueden ser definidas aquí
}