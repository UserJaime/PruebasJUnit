package org.example.Ejercicio12;

public class ComponenteB {
    /**
     * Realiza una operación en el ComponenteB.
     * @return El resultado de la operación.
     */
    public int operacionB() {
        // Lógica de la operación B
        return 42; // Un resultado de ejemplo
    }
}